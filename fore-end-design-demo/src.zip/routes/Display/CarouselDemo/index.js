import React from 'react'
import {Card, Carousel, Comment, Avatar, List, Form, Button, Input, Select} from 'antd'
import CustomBreadcrumb from '../../../components/CustomBreadcrumb/index'
import TypingCard from '../../../components/TypingCard'
import './css/style.css'
import 'animate.css'
import moment from 'moment'

const { TextArea } = Input;
const { Option } = Select;

const CommentList = ({ comments }) => (
  <List
    dataSource={comments}
    header={`${comments.length}条讨论`}
    itemLayout="horizontal"
    renderItem={props => <Comment {...props} />}
  />
);

const Editor = ({ onChange, onSubmit, submitting, value }) => (
  <div>
    <Form.Item>
      <TextArea rows={4} onChange={onChange} value={value} />
    </Form.Item>
    <Form.Item>
      <Button htmlType="submit" loading={submitting} onClick={onSubmit} type="primary">
        添加讨论
      </Button>
    </Form.Item>
  </div>
);

class CarouselDemo extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      experiments: [
        '实验1',
        '实验2',
        '实验3',
      ],
      chosenExperiment: '实验1',
      comments: [
        {
          author: 'Anonymous',
          avatar: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
          content: <p>这是一个测试。</p>,
          datetime: '很久很久以前',
          type: 'teacher',
        },
      ],
      submitting: false,
      value: '',
      u_avatar: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
      u_name: 'Admin',
      u_type: 'teacher',
    }
  }

  // 载入页面时需要获取每个comment的名字头像内容时间信息

  handleSubmit = () => {
    if (!this.state.value) {
      return;
    }

    this.setState({
      submitting: true,
    });

    setTimeout(() => {
      this.setState({
        submitting: false,
        value: '',
        comments: [
          {
            author: this.state.u_name + (this.state.u_type == 'teacher' ? '老师' : ''),
            avatar: this.state.u_avatar,
            content: <p>{this.state.value}</p>,
            datetime: moment().fromNow(),
          },
          ...this.state.comments,
        ],
      });
    }, 1000);

    // 提交时要把内容传给后端
  };

  handleChange = e => {
    this.setState({
      value: e.target.value,
    });
  };

  onChangeExperiment = value => {
    this.setState({
      chosenExperiment: value,
    })
  }

  render() {
    const { comments, submitting, value, u_name, u_avatar, experiments } = this.state;
    const cardContent = `
      <li>这个页面用来讨论实验内容。</li>
      <li>教师的发言会被高亮表示方便学生看得更清楚。</li>
    `
    return (
      <div>
        <CustomBreadcrumb arr={['实验功能', '实验讨论']} />
        <TypingCard source={cardContent} />
        <Card title='实验讨论'>
          <Select showSearch style={{ width: 200 }} placeholder='选择实验' onChange={this.onChangeExperiment}>
            {
              experiments.map(experiment => (
                <Option key={experiment}>
                  {experiment}
                </Option>
              ))
            }
          </Select>
          {comments.length > 0 && <CommentList comments={comments} />}
          <Comment
            avatar={
              <Avatar
                src={u_avatar}
                alt={u_name}
              />
            }
            content={
              <Editor
                onChange={this.handleChange}
                onSubmit={this.handleSubmit}
                submitting={submitting}
                value={value}
              />
            }
          />
        </Card>
      </div>
    )
  }
}

const styles = {
  highlighted: {
    colors:'#0000FF',
  },
}

export default CarouselDemo